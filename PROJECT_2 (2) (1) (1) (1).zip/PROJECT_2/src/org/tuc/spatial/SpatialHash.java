// SpatialHash.java
package org.tuc.spatial;

import java.util.ArrayList;
import java.util.List;

public class SpatialHash implements SpatialStructure {
    private int K,D,bucket,slots;
    private List<TucPoint>[] table;
    private static ThreadLocal<Integer> counter=ThreadLocal.withInitial(()->0);

    @SuppressWarnings("unchecked")
    public SpatialHash(int K,int D,int bucket){
        this.K=K;this.D=D;this.bucket=bucket;
        slots=(K+bucket-1)/bucket;
        table=(List<TucPoint>[])new List[slots*slots];
        for(int i=0;i<table.length;i++)table[i]=new ArrayList<>();
    }
    @Override public boolean insert(TucPoint p){
        int x=p.getX(),y=p.getY();
        if(x<0||x>=K||y<0||y>=K) return false;
        int idx=hash(x,y); return table[idx].add(p);
    }
    @Override public TucPoint search(int x,int y){
        if(x<0||x>=K||y<0||y>=K) return null;
        int idx=hash(x,y);
        for(TucPoint p:table[idx]) if(p.getX()==x&&p.getY()==y) return p;
        return null;
    }
    @Override public ArrayList<TucPoint> rangeSearch(int x1,int y1,int x2,int y2){
        int ax=Math.max(0,x1),bx=Math.min(K-1,x2),ay=Math.max(0,y1),by=Math.min(K-1,y2);
        ArrayList<TucPoint> res=new ArrayList<>();
        int ix1=ax/bucket,iy1=ay/bucket,ix2=bx/bucket,iy2=by/bucket;
        for(int ix=ix1;ix<=ix2;ix++)for(int iy=iy1;iy<=iy2;iy++){
            int idx=ix+iy*slots;
            for(TucPoint p:table[idx]){
                int px=p.getX(),py=p.getY();
                if(px>=ax&&px<=bx&&py>=ay&&py<=by)res.add(p);
            }
        }
        return res;
    }
    @Override public ArrayList<TucPoint> findNearPoints(int x,int y){
        return rangeSearch(x-D,y-D,x+D,y+D);
    }
    private int hash(int x,int y){return x/bucket+y/bucket*slots;}

    // Counting API
    public static int singleSearchCount(SpatialHash sh,int x,int y){
        counter.set(0); sh.countSearch(x,y); return counter.get();
    }
    private void countSearch(int x,int y){
        counter.set(counter.get()+1);
        int idx=hash(x,y);
        for(TucPoint p:table[idx]){counter.set(counter.get()+1);
            if(p.getX()==x&&p.getY()==y) return;
        }
    }
    public static int rangeSearchCount(SpatialHash sh,int x1,int y1,int x2,int y2){
        counter.set(0); sh.countRange(x1,y1,x2,y2); return counter.get();
    }
    private void countRange(int x1,int y1,int x2,int y2){
        counter.set(counter.get()+1);
        int ax=Math.max(0,x1),bx=Math.min(K-1,x2),ay=Math.max(0,y1),by=Math.min(K-1,y2);
        int ix1=ax/bucket,iy1=ay/bucket,ix2=bx/bucket,iy2=by/bucket;
        for(int ix=ix1;ix<=ix2;ix++)for(int iy=iy1;iy<=iy2;iy++){
            counter.set(counter.get()+1);
            int idx=ix+iy*slots;
            for(TucPoint p:table[idx])counter.set(counter.get()+1);
        }
    }
}
