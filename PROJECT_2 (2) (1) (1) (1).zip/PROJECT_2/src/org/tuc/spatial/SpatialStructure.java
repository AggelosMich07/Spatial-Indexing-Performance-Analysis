// SpatialStructure.java
package org.tuc.spatial;

import java.util.ArrayList;

public interface SpatialStructure {
    boolean insert(TucPoint p);
    TucPoint search(int x, int y);
    ArrayList<TucPoint> rangeSearch(int x1, int y1, int x2, int y2);
    ArrayList<TucPoint> findNearPoints(int x, int y);
}
