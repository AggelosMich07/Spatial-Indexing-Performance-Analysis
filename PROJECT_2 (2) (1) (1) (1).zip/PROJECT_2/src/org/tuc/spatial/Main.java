package org.tuc.spatial ;
import java.util.*;
import java.io.*;

public class Main {

    public static List<Monster> readMonsterFromDisk(int N, String density) {
        List<Monster> monsters = new ArrayList<>();
        String filename = String.format("./data/monsters_%d_%s.bin", N, density);

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            for (int i = 0; i < N; i++) {
                monsters.add((Monster) ois.readObject());
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return monsters;
    }

    public static void main(String[] args) {

        int K = 1024;
        int D = 10;
        int[] Ns = {200, 500, 2000, 5000, 10000};

        for (int N : Ns) {
            System.out.println("\n============================");
            System.out.println("Εκτέλεση για Ν = " + N);
            System.out.println("============================\n");

            QuadTree qt = new QuadTree(K, D);
            SpatialHash h4 = new SpatialHash(K, D, 4);
            SpatialHash h32 = new SpatialHash(K, D, 32);

            List<Monster> monsters = readMonsterFromDisk(N, "dense");
            for (Monster m : monsters) {
                qt.insert(m);
                h4.insert(m);
                h32.insert(m);
            }

            // Μέτρηση για S1, S2, S3
            int[][] queriesS = {{100, 100}, {512, 512}, {900, 800}};
            for (int i = 0; i < queriesS.length; i++) {
                int x = queriesS[i][0];
                int y = queriesS[i][1];

                long start1 = System.nanoTime();
                qt.search(x, y);
                long end1 = System.nanoTime();

                long start2 = System.nanoTime();
                h4.search(x, y);
                long end2 = System.nanoTime();

                long start3 = System.nanoTime();
                h32.search(x, y);
                long end3 = System.nanoTime();

                System.out.printf("S%d - QT time: %.4fms\n", i + 1, (end1 - start1) / 10.0);
                System.out.printf("S%d - H4 time: %.4fms\n", i + 1, (end2 - start2) / 10.0);
                System.out.printf("S%d - H32 time: %.4fms\n\n", i + 1, (end3 - start3) / 10.0);
            }

            // Μέτρηση για R1, R2, R3
            int[][] queriesR = {{100, 100, 50}, {512, 512, 128}, {900, 800, 200}};
            for (int i = 0; i < queriesR.length; i++) {
                int x = queriesR[i][0];
                int y = queriesR[i][1];
                int range = queriesR[i][2];

                long start1 = System.nanoTime();
                qt.findNearPoints(x, y);
                long end1 = System.nanoTime();

                long start2 = System.nanoTime();
                h4.findNearPoints(x, y);
                long end2 = System.nanoTime();

                long start3 = System.nanoTime();
                h32.findNearPoints(x, y);
                long end3 = System.nanoTime();

                System.out.printf("R%d - QT time: %.4fms\n", i + 1, (end1 - start1) / 10.0);
                System.out.printf("R%d - H4 time: %.4fms\n", i + 1, (end2 - start2) / 10.0);
                System.out.printf("R%d - H32 time: %.4fms\n\n", i + 1, (end3 - start3) / 10.0);
            }

            // Ερώτημα 2ε για N = 10000
            if (N == 10000) {
                int[][] checkPoints = {
                    {1018, 558}, {992, 518}, {594, 646},
                    {581, 836}, {718, 827}, {633, 930}
                };

                System.out.println("\n==== Έλεγχος 2ε - Αναζήτηση Θηρίων στα 6 Σημεία ====");

                for (int[] point : checkPoints) {
                    int x = point[0], y = point[1];

                    TucPoint a = qt.search(x, y);
                    TucPoint b = h4.search(x, y);
                    TucPoint c = h32.search(x, y);

                    System.out.printf("Σημείο (%d, %d):\n", x, y);
                    System.out.println("  QuadTree:     " + (a != null ? ((Monster) a).getName() : "null"));
                    System.out.println("  SpatialHash4: " + (b != null ? ((Monster) b).getName() : "null"));
                    System.out.println("  SpatialHash32:" + (c != null ? ((Monster) c).getName() : "null"));
                    System.out.println();
                }

                System.out.println("==== Έλεγχος 2ε - Θηρία κοντά στο (900, 688) ====");

                int nearX = 900, nearY = 688;

                List<TucPoint> list1 = qt.findNearPoints(nearX, nearY);
                List<TucPoint> list2 = h4.findNearPoints(nearX, nearY);
                List<TucPoint> list3 = h32.findNearPoints(nearX, nearY);

                System.out.println("\nQuadTree:");
                for (TucPoint t1 : list1) System.out.println("  " + ((Monster) t1).getName());

                System.out.println("\nSpatialHash4:");
                for (TucPoint t2 : list2) System.out.println("  " + ((Monster) t2).getName());

                System.out.println("\nSpatialHash32:");
                for (TucPoint t3 : list3) System.out.println("  " + ((Monster) t3).getName());
            }
        }
    }
}