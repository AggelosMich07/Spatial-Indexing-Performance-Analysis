// QuadTree.java
package org.tuc.spatial;

import java.util.ArrayList;
import java.util.List;

public class QuadTree implements SpatialStructure {
    private int K, D;
    private QuadNode root;
    private static ThreadLocal<Integer> counter = ThreadLocal.withInitial(() -> 0);

    private class QuadNode {
        int x1, y1, x2, y2;
        TucPoint point;
        QuadNode[] children;
        QuadNode(int x1, int y1, int x2, int y2) {
            this.x1 = x1; this.y1 = y1; this.x2 = x2; this.y2 = y2;
            this.point = null; this.children = null;
        }
        boolean isLeaf() { return children == null; }
        boolean contains(int x, int y) { return x>=x1&&x<=x2&&y>=y1&&y<=y2; }
    }

    public QuadTree(int K, int D) {
        this.K = K; this.D = D; this.root = new QuadNode(0,0,K-1,K-1);
    }

    @Override public boolean insert(TucPoint p) { return insert(root,p); }
    private boolean insert(QuadNode node, TucPoint p) {
        if (!node.contains(p.getX(),p.getY())) return false;
        if (node.isLeaf()) {
            if (node.point==null) { node.point=p; return true; }
            subdivide(node);
            TucPoint old=node.point; node.point=null;
            insertIntoChildren(node,old);
        }
        return insertIntoChildren(node,p);
    }
    private boolean insertIntoChildren(QuadNode node, TucPoint p) {
        for (QuadNode c: node.children) if (c.contains(p.getX(),p.getY())) return insert(c,p);
        return false;
    }
    private void subdivide(QuadNode node) {
        int mx=(node.x1+node.x2)/2,my=(node.y1+node.y2)/2;
        node.children=new QuadNode[4];
        node.children[0]=new QuadNode(node.x1,node.y1,mx,my);
        node.children[1]=new QuadNode(mx+1,node.y1,node.x2,my);
        node.children[2]=new QuadNode(node.x1,my+1,mx,node.y2);
        node.children[3]=new QuadNode(mx+1,my+1,node.x2,node.y2);
    }

    @Override public TucPoint search(int x,int y){ return searchNode(root,x,y); }
    private TucPoint searchNode(QuadNode node,int x,int y){
        if(node==null||!node.contains(x,y))return null;
        if(node.isLeaf()){
            return (node.point!=null&&node.point.getX()==x&&node.point.getY()==y)?node.point:null;
        }
        for(QuadNode c:node.children) if(c.contains(x,y)) return searchNode(c,x,y);
        return null;
    }

    @Override public ArrayList<TucPoint> rangeSearch(int x1,int y1,int x2,int y2){
        ArrayList<TucPoint> res=new ArrayList<>();
        rangeNode(root,x1,y1,x2,y2,res);
        return res;
    }
    private void rangeNode(QuadNode node,int x1,int y1,int x2,int y2,List<TucPoint> res){
        if(node==null||node.x2<x1||node.x1>x2||node.y2<y1||node.y1>y2) return;
        if(node.isLeaf()){
            if(node.point!=null){
                int px=node.point.getX(),py=node.point.getY();
                if(px>=x1&&px<=x2&&py>=y1&&py<=y2) res.add(node.point);
            }
        } else for(QuadNode c:node.children) rangeNode(c,x1,y1,x2,y2,res);
    }

    @Override public ArrayList<TucPoint> findNearPoints(int x,int y){
        int x1=Math.max(0,x-D),y1=Math.max(0,y-D),x2=Math.min(K-1,x+D),y2=Math.min(K-1,y+D);
        return rangeSearch(x1,y1,x2,y2);
    }

    // Counting API for avg nodes
    public static int singleSearchCount(QuadTree qt,int x,int y){
        counter.set(0); qt.countSearch(qt.root,x,y); return counter.get();
    }
    private void countSearch(QuadNode node,int x,int y){
        counter.set(counter.get()+1);
        if(node==null||!node.contains(x,y))return;
        if(node.isLeaf())return;
        for(QuadNode c:node.children) if(c.contains(x,y)){countSearch(c,x,y);return;}
    }
    public static int rangeSearchCount(QuadTree qt,int x1,int y1,int x2,int y2){
        counter.set(0); qt.countRange(qt.root,x1,y1,x2,y2); return counter.get();
    }
    private void countRange(QuadNode node,int x1,int y1,int x2,int y2){
        counter.set(counter.get()+1);
        if(node==null||node.x2<x1||node.x1>x2||node.y2<y1||node.y1>y2) return;
        if(node.isLeaf())return;
        for(QuadNode c:node.children) countRange(c,x1,y1,x2,y2);
    }
}
