// DataLoader.java
package org.tuc.spatial;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class DataLoader {
    public static List<TucPoint> loadPoints(String filepath) throws IOException {
        List<TucPoint> pts=new ArrayList<>();
        try(DataInputStream in=new DataInputStream(new BufferedInputStream(new FileInputStream(filepath)))) {
            while(true){
                int x=in.readInt(),y=in.readInt();
                pts.add(new TucPoint(x,y));
            }
        } catch(EOFException eof) {}
        return pts;
    }
    public static TucPoint[] loadQueries(String filepath)throws IOException{
        List<TucPoint> qs=loadPoints(filepath);
        return qs.toArray(new TucPoint[0]);
    }
}
